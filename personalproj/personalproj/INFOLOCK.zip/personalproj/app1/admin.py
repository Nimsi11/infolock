from django.contrib import admin
from app1.models import logintable,usertable,personaltable,educationtable,medicaltable,accounttable,familytable
admin.site.register(logintable)
admin.site.register(usertable)
admin.site.register(personaltable)
admin.site.register(educationtable)
admin.site.register(medicaltable)
admin.site.register(accounttable)
admin.site.register(familytable)
# Register your models here.
